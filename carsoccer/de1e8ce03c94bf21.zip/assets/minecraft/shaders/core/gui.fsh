#version 330
#extension GL_ARB_separate_shader_objects : require

// The game's own gui.fsh, plus: the darkening behind in-game menus (a gradient from 0xC0101010 to 0xD0101010) is
// not drawn. Car Soccer's menus draw their own window.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};

layout(location = 0) in vec4 vertexColor;

layout(location = 0) out vec4 fragColor;

void main() {
    vec4 color = vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    if (all(lessThan(abs(color.rgb - vec3(16.0 / 255.0)), vec3(0.003))) && color.a > 0.74 && color.a < 0.83) {
        discard;
    }
    fragColor = color * ColorModulator;
}
