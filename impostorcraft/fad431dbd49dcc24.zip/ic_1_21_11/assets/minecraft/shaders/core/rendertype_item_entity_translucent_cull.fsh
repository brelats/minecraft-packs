#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;

out vec4 fragColor;

void main() {
    // Impostor Craft: your own crewmate model (marked texels) hides while the camera is inside it.
    float icA = texture(Sampler0, texCoord0).a * 255.0;
    if ((abs(icA - 50.0) < 0.5 || abs(icA - 58.0) < 0.5 || abs(icA - 65.0) < 0.5 || abs(icA - 70.0) < 0.5 || abs(icA - 254.0) < 0.5) && gl_FragCoord.w > 0.4545) {
        discard;
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
