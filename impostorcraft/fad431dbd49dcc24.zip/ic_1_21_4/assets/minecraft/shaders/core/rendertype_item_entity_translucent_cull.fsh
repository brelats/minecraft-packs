#version 150

#moj_import <minecraft:fog.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;

out vec4 fragColor;

void main() {
    // Impostor Craft: your own crewmate model (marked texels) hides while the camera is inside it.
    float icA = texture(Sampler0, texCoord0).a * 255.0;
    if ((abs(icA - 50.0) < 0.5 || abs(icA - 58.0) < 0.5 || abs(icA - 65.0) < 0.5 || abs(icA - 70.0) < 0.5 || abs(icA - 254.0) < 0.5) && gl_FragCoord.w > 0.4545) {
        discard;
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
